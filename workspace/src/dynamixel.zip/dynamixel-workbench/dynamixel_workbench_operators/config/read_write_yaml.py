import yaml

with open(r'/home/vamsi/ws_moveit/src/dynamixel-workbench/dynamixel_workbench_operators/config/motion _test.yaml') as file:
    documents = yaml.full_load(file)
    print(documents)
    # for item, doc in documents.items():
    #     print(item, ":", doc)
    print(type(documents["motion"]["right"]["step"]))
    documents["motion"]["right"]["step"][0] = 0
    documents["motion"]["right"]["step"][1] = 0

dict_file = [documents]
print(dict_file)
with open(r'/home/vamsi/ws_moveit/src/dynamixel-workbench/dynamixel_workbench_operators/config/store_file.yaml', 'w') as file_2:
    documents = yaml.dump(documents, file_2)